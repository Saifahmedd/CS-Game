package views;

import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Checkk {
	public static void checkWin(Stage stage) {
		BorderPane root = new BorderPane();
		Image backk1 = new Image("winning.jpg");
		BackgroundImage backk = new BackgroundImage(backk1, null, null, null, new BackgroundSize(1.0,1.0, false, false, false, false));
		Background back = new Background(backk);
		root.setBackground(back);
		Scene sceneWin = new Scene(root);
		stage.setScene(sceneWin);
	}
	
	public static void lose(Stage stage) {
		BorderPane root = new BorderPane();
		Image backk1 = new Image("Game Over.jpg");
		BackgroundImage backk = new BackgroundImage(backk1, null, null, null, new BackgroundSize(1.0,1.0, false, false, false, false));
		Background back = new Background(backk);
		root.setBackground(back);
		Scene sceneLose = new Scene(root);
		stage.setScene(sceneLose);
	}
}
