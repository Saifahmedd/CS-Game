package views;

import java.awt.Point;
import java.util.ArrayList;
import java.util.concurrent.CancellationException;
import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.MovementException;
import exceptions.NoAvailableResourcesException;
import exceptions.NotEnoughActionsException;
import javafx.animation.ScaleTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.characters.Direction;
import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.collectibles.Collectible;
import model.collectibles.Vaccine;
import model.world.CharacterCell;
import model.world.CollectibleCell;
import model.world.TrapCell;
import model.characters.Hero;

public class scene3 {
   
	public static void scene3(Stage stage, Image image,Hero h, ArrayList<Image> arrimage, ArrayList<String> arrName){
		GridPane grid = new GridPane();
		BorderPane root = new BorderPane();
	    grid.setAlignment(Pos.CENTER);
	    ArrayList<Button> zombieButtons = new ArrayList<Button>();
	   
	    Image up1 = new Image("Arrow Up.jpg");
	    Image down1 = new Image("Arrow Down.jpg");
	    Image right1 = new Image("Arrow Right.jpg");
	    Image left1 = new Image("Arrow Left.jpg");
	    
	    BackgroundImage up2 = new BackgroundImage(up1, null, null, null, new BackgroundSize(40,40, false, false, false, false));
	    BackgroundImage down2 = new BackgroundImage(down1, null, null, null, new BackgroundSize(40,40, false, false, false, false));
	    BackgroundImage right2 = new BackgroundImage(right1, null, null, null, new BackgroundSize(40,40, false, false, false, false));
	    BackgroundImage left2 = new BackgroundImage(left1, null, null, null, new BackgroundSize(40,40, false, false, false, false));
	    
	    Background up3 = new Background(up2);
	    Background down3 = new Background(down2);
	    Background right3 = new Background(right2);
	    Background left3 = new Background(left2);
	    
	    Button up = new Button();
	    up.setBackground(up3);
	    up.setPrefSize(40, 40);
	    
	    Button down = new Button();
	    down.setBackground(down3);
	    down.setPrefSize(40, 40);
	    
	    Button left = new Button();
	    left.setBackground(left3);
	    left.setPrefSize(40, 40);
	    
	    Button right = new Button();
	    right.setBackground(right3);
	    right.setPrefSize(40, 40);
	    
	    GridPane grid2 = new GridPane();
	    for(int i=0; i<3; i++) {
	    	for(int j=0; j<3; j++) {
	    		if(i == 1 && j == 0) {
	    			grid2.add(up, i, j);
	    			BorderStroke borderStroke = new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(2));
	                Border border2 = new Border(borderStroke);
	                up.setBorder(border2); 
	                up.setOnMouseEntered(e-> {
	        			ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.2),up);
	                    scaleTransition.setToX(1.2);
	                    scaleTransition.setToY(1.2);
	                    scaleTransition.setAutoReverse(true);
	                    scaleTransition.play();
	        		});
	                up.setOnMouseExited(e-> {
	        			ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.2), up);
	        		    scaleTransition.setToX(1);
	        		    scaleTransition.setToY(1);
	        		    scaleTransition.play();
	        		});	

	    		}
	    		else if(i == 1 && j == 2) {
	    			grid2.add(down, i, j);
	    			BorderStroke borderStroke = new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(2));
	                Border border2 = new Border(borderStroke);
	                down.setBorder(border2); 
	                down.setOnMouseEntered(e-> {
	        			ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.2),down);
	                    scaleTransition.setToX(1.2);
	                    scaleTransition.setToY(1.2);
	                    scaleTransition.setAutoReverse(true);
	                    scaleTransition.play();
	        		});
	                down.setOnMouseExited(e-> {
	        			ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.2), down);
	        		    scaleTransition.setToX(1);
	        		    scaleTransition.setToY(1);
	        		    scaleTransition.play();
	        		});	

	    		}
	    		else if(i == 0 && j == 1) {
	    			grid2.add(left, i, j);
	    			BorderStroke borderStroke = new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(2));
	                Border border2 = new Border(borderStroke);
	                left.setBorder(border2); 
	                left.setOnMouseEntered(e-> {
	        			ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.2),left);
	                    scaleTransition.setToX(1.2);
	                    scaleTransition.setToY(1.2);
	                    scaleTransition.setAutoReverse(true);
	                    scaleTransition.play();
	        		});
	                left.setOnMouseExited(e-> {
	        			ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.2), left);
	        		    scaleTransition.setToX(1);
	        		    scaleTransition.setToY(1);
	        		    scaleTransition.play();
	        		});	

	    		}
	    		else if(i == 2 && j == 1) {
	    			grid2.add(right, i, j);
	    			BorderStroke borderStroke = new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(2));
	                Border border2 = new Border(borderStroke);
	                right.setBorder(border2); 
	                right.setOnMouseEntered(e-> {
	        			ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.2),right);
	                    scaleTransition.setToX(1.2);
	                    scaleTransition.setToY(1.2);
	                    scaleTransition.setAutoReverse(true);
	                    scaleTransition.play();
	        		});
	                right.setOnMouseExited(e-> {
	        			ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.2), right);
	        		    scaleTransition.setToX(1);
	        		    scaleTransition.setToY(1);
	        		    scaleTransition.play();
	        		});	

	    		}
	    		
	    	}
	    }
	    
	    for(int i=0; i<15; i++) {
			for(int j=0; j<15; j++) {
				Button cells = new Button();
				cells.setPrefSize(40, 40);
				if(Game.map[i][j].isVisible()) {
				if(Game.map[i][j] instanceof CollectibleCell) {
					CollectibleCell c = (CollectibleCell) Game.map[i][j];
					if(c.getCollectible() instanceof Vaccine) {
						Image image3 = new Image("medkit.jpg"); 
						BackgroundImage backk = new BackgroundImage(image3, null, null, null, new BackgroundSize(40,40, false, false, false, false));
						Background image2 = new Background(backk);
						cells.setBackground(image2);
						grid.add(cells, j, 14-i);
					}
					else {
						Image image3 = new Image("Shield.png"); 
						BackgroundImage backk = new BackgroundImage(image3, null, null, null, new BackgroundSize(40,40, false, false, false, false));
						Background image2 = new Background(backk);
						cells.setBackground(image2);
						grid.add(cells, j, 14-i);
					}
				}
				if(Game.map[i][j] instanceof CharacterCell) {
					CharacterCell c = (CharacterCell) Game.map[i][j];
					if(c.getCharacter() == null) {
						grid.add(cells, j, 14-i);
					}
					if(c.getCharacter() instanceof Zombie) {
					    Image image3 = new Image("zombie.jpg"); 
						BackgroundImage backk = new BackgroundImage(image3, null, null, null, new BackgroundSize(40,40, false, false, false, false));
						Background image2 = new Background(backk);
						cells.setBackground(image2);
						zombieButtons.add(cells);
						grid.add(cells, j, 14-i);
					}
				}else if(Game.map[i][j] instanceof TrapCell) {
					grid.add(cells, j, 14-i);
				}
			}
				else {
					Image img = new Image("Visibility.jpg");
					BackgroundImage backimg = new BackgroundImage(img, null, null, null, new BackgroundSize(40,40, false, false, false, false));
					Background back = new Background(backimg);
					cells.setBackground(back);
					grid.add(cells, j, 14-i);
				}
				BorderStroke borderStroke = new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(2));
                Border border = new Border(borderStroke);
                cells.setBorder(border);
			}
	    }
	    
	    VBox onRight = new VBox();
	    Button attackButton = new Button("Attack");
	    attackButton.setFont(Font.font("Arial",20));
	    Button specialButton = new Button("Special");
	    specialButton.setFont(Font.font("Arial",20));
	    Button cureButton = new Button("Cure");
	    cureButton.setFont(Font.font("Arial",20));
	    Button endTurn = new Button("End Turn");
	    endTurn.setFont(Font.font("Arial",20));
	    
		VBox data = new VBox();
		
	    for(int i=0; i<Game.heroes.size(); i++) {
	    	Button hero = new Button();
	    	info(data);
	    	hero.setPrefSize(40, 40);
	    	Hero h2 = Game.heroes.get(i);
	    	String s = h2.getName();
	    	int x = h2.getLocation().x;
	    	int y = h2.getLocation().y;
	    	Image img = whichImage(arrimage,arrName,s);
	    	BackgroundImage backimg1 = new BackgroundImage(img, null, null, null, new BackgroundSize(40,40, false, false, false, false));
	    	Background backimg = new Background(backimg1);
	    	hero.setBackground(backimg);
	    	grid.add(hero, y, 14-x);
	    	
	    	hero.setOnAction(e->{
	    		up.setOnAction(event->{
	    			movee(grid,h,Direction.UP, backimg, data);
	    		});
	    		down.setOnAction(event->{
	    			movee(grid,h,Direction.DOWN, backimg, data);
	    		});
	    		left.setOnAction(event->{
	    			movee(grid,h,Direction.LEFT, backimg, data);
	    		});
	    		right.setOnAction(event->{
	    			movee(grid,h,Direction.RIGHT, backimg, data);
	    		});
	    		attackButton.setOnAction(event->{
	    			zombieAttack(h,grid, data);
	    		});
	    		cureButton.setOnAction(event->{
	    			cureAction(h,grid,data, arrimage, arrName);
	    		});
	    		specialButton.setOnAction(event->{
	    			useSpecialActions(h,grid);
	    		});
	    	});
	    }
	    
	    endTurn.setOnAction(e->{
	    	try {
				Game.endTurn();
				checkForVisibility(grid,h);
				info(data);
				if(Game.checkWin() == true) {
					Checkk.checkWin(stage);
				}
				else {
					if(Game.checkGameOver() == true) {
						Checkk.lose(stage);
					}	
				}
			} catch (NotEnoughActionsException e1) {
				Alert alert = new Alert(Alert.AlertType.WARNING);
				alert.setTitle("Error!");
				alert.setContentText(e1.getMessage());
				
				alert.showAndWait();
			} catch (InvalidTargetException e1) {
				Alert alert = new Alert(Alert.AlertType.WARNING);
				alert.setTitle("Error!");
				alert.setContentText(e1.getMessage());
				
				alert.showAndWait();
			}
	    });
	    
	    onRight.getChildren().addAll(attackButton,specialButton,cureButton,endTurn);

		Image backgroundImage = new Image("backgrond grid.jpg");
		BackgroundImage background = new BackgroundImage(backgroundImage, null, null, null, new BackgroundSize(1.0, 1.0, true, true, false, false));
	    root.setBackground(new Background(background));
        root.setCenter(grid);
        root.setLeft(data);
        root.setRight(onRight);
        root.setBottom(grid2);

        Scene scene3 = new Scene(root);
	    stage.setScene(scene3);
    	stage.setResizable(false);
	    stage.setFullScreen(true);
	    stage.show();
	}
	public static void movee(GridPane grid, Hero h, Direction dir, Background img, VBox data) {
	    	int x = h.getLocation().x;
	    	int y = h.getLocation().y;
	    	try {
				h.move(dir);
			} catch (MovementException e) {
				Alert alert = new Alert(Alert.AlertType.WARNING);
				alert.setTitle("Error!");
				alert.setContentText(e.getMessage());
				
				alert.showAndWait();
			} catch (NotEnoughActionsException e) {
				Alert alert = new Alert(Alert.AlertType.WARNING);
				alert.setTitle("Error!");
				alert.setContentText(e.getMessage());
				
				alert.showAndWait();
			}
	    	Button oldButt = new Button();
	    	oldButt.setPrefSize(40,40);
	    	Image cell = new Image("Arrow Down.jpg");
			BackgroundImage background = new BackgroundImage(cell, null, null, null, new BackgroundSize(40, 40, false, false, false, false));
	    	Background img1 = new Background(background);
			oldButt.setBackground(img1);
	    	grid.add(oldButt, y, 14-x);
	    	int newX = h.getLocation().x;
	    	int newY = h.getLocation().y;
	    	if(Game.map[newX][newY] instanceof TrapCell) {
	    		info(data);
	    		Alert alert = new Alert(Alert.AlertType.WARNING);
				alert.setTitle("Warning");
				alert.setContentText("The Hero moved in a TrapCell");
				
				alert.showAndWait();
	    	}
	    	Button newButt = new Button();
	    	newButt.setPrefSize(40, 40);
	    	newButt.setBackground(img);
	    	grid.add(newButt, newY, 14-newX);
	    	checkForVisibility(grid,h);
	    	info(data);
	}
	
	public static void info(VBox data) {
		data.getChildren().removeAll(data.getChildren());
			for(int i=0;i<Game.heroes.size(); i++) {	
				Hero hero = Game.heroes.get(i);
				String a1 = hero.getName();
			    String a2 = hero.getCurrentHp() + "";
			    String a3 = hero.getAttackDmg() + "";
			    String a4 = hero.getActionsAvailable() + "";
			    String a5;
			    if(hero instanceof Fighter)
			    	a5 = "Fighter";
			    if(hero instanceof Medic)
			    	a5 = "Medic";
			    else
			    	a5 = "Explorer";
			    
			    String a6 =  hero.getVaccineInventory().size() + "";
			    String a7 = hero.getSupplyInventory().size() + "";
			    String heroInfo = "Hero Name: " + a1 + "\n" + "Type: "+ a5 + "\n"+ "CurrentHp: " + a2 + "\n" + "Attack Damage: " + a3 + "\n" + "Actions Available: " + a4 + "\n" + "Vaccines: " + a6 + "\n" + "Supplies: " + a7 + "\n";                 
			    Label gridInfo = new Label(heroInfo);
			    gridInfo.setFont(Font.font("Arial",20));
			    gridInfo.setTextFill(Color.WHITE);
			    data.getChildren().add(gridInfo);
			}
	}
	
	public static void checkForVisibility(GridPane grid, Hero h) {
		for(int i=0; i<15; i++) {
			for(int j=0; j<15; j++) {
				Button cells = new Button();
				cells.setPrefSize(40, 40);
				if(Game.map[i][j].isVisible()) {
				if(Game.map[i][j] instanceof CollectibleCell) {
					CollectibleCell c = (CollectibleCell) Game.map[i][j];
					if(c.getCollectible() instanceof Vaccine) {
						Image image3 = new Image("medkit.jpg"); 
						BackgroundImage backk = new BackgroundImage(image3, null, null, null, new BackgroundSize(40,40, false, false, false, false));
						Background image2 = new Background(backk);
						cells.setBackground(image2);
						grid.add(cells, j, 14-i);
					}
					else {
						Image image3 = new Image("Shield.png"); 
						BackgroundImage backk = new BackgroundImage(image3, null, null, null, new BackgroundSize(40,40, false, false, false, false));
						Background image2 = new Background(backk);
						cells.setBackground(image2);
						grid.add(cells, j, 14-i);
					}
				}
				if(Game.map[i][j] instanceof CharacterCell) {
					CharacterCell c = (CharacterCell) Game.map[i][j];
					if(c.getCharacter() == null) {
						grid.add(cells, j, 14-i);
					}else
					if(c.getCharacter() instanceof Zombie) {
						Image image3 = new Image("zombie.jpg"); 
						BackgroundImage backk = new BackgroundImage(image3, null, null, null, new BackgroundSize(40,40, false, false, false, false));
						Background image2 = new Background(backk);
						cells.setBackground(image2);
						grid.add(cells, j, 14-i);
					}
				}else if(Game.map[i][j] instanceof TrapCell) {
					grid.add(cells, j, 14-i);
				}
			}
				else {
					Image img = new Image("Visibility.jpg");
					BackgroundImage backimg = new BackgroundImage(img, null, null, null, new BackgroundSize(40,40, false, false, false, false));
					Background back = new Background(backimg);
					cells.setBackground(back);
					grid.add(cells, j, 14-i);
				}
				BorderStroke borderStroke = new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(2));
                Border border = new Border(borderStroke);
                cells.setBorder(border);
			}
	    }
	}
	public static void zombieAttack(Hero h, GridPane grid,VBox data) {
		for(int i=0; i<Game.zombies.size(); i++) {
			Button zombie = new Button();
			zombie.setPrefSize(40, 40);
			Zombie z = Game.zombies.get(i);
		    int x = z.getLocation().x;
		    int y = z.getLocation().y;
		    Image image3 = new Image("zombie.jpg");
		    Image visible = new Image("Visibility.jpg");
		    BackgroundImage img2 = new BackgroundImage(visible, null, null, null, new BackgroundSize(40,40, false, false, false, false));
		    Background img3 = new Background(img2);
			BackgroundImage backk = new BackgroundImage(image3, null, null, null, new BackgroundSize(40,40, false, false, false, false));
			Background image2 = new Background(backk);
			if(Game.map[x][y].isVisible()) {
				zombie.setBackground(image2);
			}
			else {
				zombie.setBackground(img3);
			}
			BorderStroke borderStroke = new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(2));
            Border border = new Border(borderStroke);
            zombie.setBorder(border);
			grid.add(zombie, y, 14-x);
			zombie.setOnAction(e->{
				try {
					h.setTarget(z);
					h.attack();
					info(data);
					if(z.getCurrentHp()<=0) {
						z.onCharacterDeath();
						Button button = new Button();
						button.setPrefSize(40, 40);
						grid.add(button, y, 14-x);
					}
					if(h.getCurrentHp()<=0) {
						h.onCharacterDeath();
						Button button = new Button();
						button.setPrefSize(40, 40);
						grid.add(button, y, 14-x);
					}
				} catch (NotEnoughActionsException e1) {
					Alert alert = new Alert(Alert.AlertType.WARNING);
					alert.setTitle("Error!");
					alert.setContentText(e1.getMessage());
					
					alert.showAndWait();
				} catch (InvalidTargetException e1) {
					Alert alert = new Alert(Alert.AlertType.WARNING);
					alert.setTitle("Error!");
					alert.setContentText(e1.getMessage());
					
					alert.showAndWait();
				}
			});
		}
	}
	

	public static void cureAction(Hero h, GridPane grid,VBox data, ArrayList<Image> arrimage, ArrayList<String> arrName) {
		for(int i=0; i<Game.zombies.size(); i++) {
			Button zombie = new Button();
			zombie.setPrefSize(40, 40);
			Zombie z = Game.zombies.get(i);
		    int x = z.getLocation().x;
		    int y = z.getLocation().y;
		    Image image3 = new Image("zombie.jpg");
		    Image visible = new Image("Visibility.jpg");
		    BackgroundImage image10 = new BackgroundImage(visible, null, null, null, new BackgroundSize(40,40, false, false, false, false));
		    Background img3 = new Background(image10);
			BackgroundImage backk = new BackgroundImage(image3, null, null, null, new BackgroundSize(40,40, false, false, false, false));
			Background image2 = new Background(backk);
			if(Game.map[x][y].isVisible()) {
				zombie.setBackground(image2);
			}
			else {
				zombie.setBackground(img3);
			}
			grid.add(zombie, y, 14-x);
			zombie.setOnAction(e->{
				try {
					h.setTarget(z);
					int x1 = z.getLocation().x;
					int y1 = z.getLocation().y;
					h.cure();
					Hero h1 = Game.heroes.get(Game.heroes.size()-1);
					String s = h1.getName();
					Image img = whichImage(arrimage,arrName,s);
					Button newHero = new Button();
					newHero.setPrefSize(40, 40);
					BackgroundImage img2 = new BackgroundImage(img, null, null, null, new BackgroundSize(40,40, false, false, false, false));
					Background backimg = new Background(img2);
					newHero.setBackground(backimg);
					grid.add(newHero, y1, 14-x1);	
				} catch (NoAvailableResourcesException e1) {
					Alert alert = new Alert(Alert.AlertType.WARNING);
					alert.setTitle("Error!");
					alert.setContentText(e1.getMessage());
					
					alert.showAndWait();
				} catch (InvalidTargetException e1) {
					Alert alert = new Alert(Alert.AlertType.WARNING);
					alert.setTitle("Error!");
					alert.setContentText(e1.getMessage());
					
					alert.showAndWait();
				} catch (NotEnoughActionsException e1) {
					Alert alert = new Alert(Alert.AlertType.WARNING);
					alert.setTitle("Error!");
					alert.setContentText(e1.getMessage());
					
					alert.showAndWait();
				}
			});
	}
}
	public static Image whichImage(ArrayList<Image> arrimage, ArrayList<String> arrName, String s) {
		int index=0;
		for(int i=0; i<arrName.size(); i++) {
			if(arrName.get(i).equals(s))
				index = i;
		}
		return arrimage.get(index);
	}
	
	public static void useSpecialActions(Hero h, GridPane grid) {
		try {
			h.useSpecial();
			if(h instanceof Explorer) {
				checkForVisibility(grid,h);
			}
		} catch (NoAvailableResourcesException e) {
			Alert alert = new Alert(Alert.AlertType.WARNING);
			alert.setTitle("Error!");
			alert.setContentText(e.getMessage());
			
			alert.showAndWait();
		} catch (InvalidTargetException e) {
			Alert alert = new Alert(Alert.AlertType.WARNING);
			alert.setTitle("Error!");
			alert.setContentText(e.getMessage());
			
			alert.showAndWait();
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}