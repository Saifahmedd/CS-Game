package views;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;

import engine.Game;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;

public class scene2 {
	public static void scene2(Stage stage) {
		BorderPane root = new BorderPane();
	    java.nio.file.Path filePath = Paths.get("C://Users//hp//Desktop//GUC//4th Semester//Game//Heroes CSV//Heros.csv");
	    String Beeb = filePath.toAbsolutePath().toString();
	    try {
	        Game.loadHeroes(Beeb);
	    } catch (IOException e1) {
	        e1.printStackTrace();
	    }
	    Button start = new Button("Start");
	    start.setPrefSize(150, 50);
	    root.setRight(start);
	    root.setAlignment(start, Pos.BOTTOM_RIGHT);
	    HBox hbox = new HBox();
	    ArrayList<Image> arrimage = new ArrayList<Image>();
	    ArrayList<String> arrName = new ArrayList<String>();
	    
	    Image x1 = new Image("Joel.jpg");
	    Image x2 = new Image("Part_II_Ellie_infobox.jpg");
	    Image x3 = new Image("Part_I_Tess_infobox.jpg");
	    Image x4 = new Image("Part_I_Riley_infobox.jpg");
	    Image x5 = new Image("Part_II_Tommy_infobox.jpg");
	    Image x6 = new Image("Part_I_Bill_infobox.jpg");
	    Image x7 = new Image("Part_I_David_infobox.jpg");
	    Image x8 = new Image("Part_I_Henry_infobox.jpg");
	    arrimage.add(0, x1);
	    arrimage.add(1, x2);
	    arrimage.add(2, x3);
	    arrimage.add(3, x4);
	    arrimage.add(4, x5);
	    arrimage.add(5, x6);
	    arrimage.add(6, x7);
	    arrimage.add(7, x8);
	    
	    arrName.add("Joel Miller");
	    arrName.add("Ellie Williams");
	    arrName.add("Tess");
	    arrName.add("Riley Abel");
	    arrName.add("Tommy Miller");
	    arrName.add("Bill");
	    arrName.add("David");
	    arrName.add("Henry Burell");
	    
	    ArrayList<Button> buttons = new ArrayList<Button>();
	    int i=0;
	    for (Hero h : Game.availableHeroes) {
		    String a1 = h.getName();
		    String a2 = h.getMaxHp() + "";
		    String a3 = h.getAttackDmg() + "";
		    String a4 = h.getMaxActions() + "";
		    String a5;
		    if(h instanceof Fighter)
		    	a5 = "Fighter";
		    if(h instanceof Medic)
		    	a5 = "Medic";
		    else
		    	a5 = "Explorer";
		    String heroInfo = "Hero Name: " + a1 + "\n" + "Type: "+ a5 + "\n"+ "MaxHp: " + a2 + "\n" + "Attack Damage: " + a3 + "\n" + "Max Actions: " + a4 + "\n";
		    
		    Button button1 = new Button(heroInfo);
		    button1.setWrapText(true);
		    button1.setPrefWidth(400);
		    VBox vbox = new VBox();
		    ImageView heroImage = new ImageView(arrimage.get(i));
		    buttons.add(button1);
		    heroImage.setFitHeight(50); // Set the height of the image
		    heroImage.setPreserveRatio(true);
		    vbox.getChildren().add(heroImage);
		    Label label = new Label();
		    vbox.getChildren().add(label);
		    vbox.setSpacing(5); // Set the spacing between the image and text
		    button1.setGraphic(vbox); // Set the VBox as the graphic of the button
		    hbox.getChildren().add(button1);
		    i++;
	    }
	    Button b0 = buttons.get(0);
	    b0.setOnAction(e->{
	    	start.setOnAction(event->{
	    		Hero h = Game.availableHeroes.get(0);
	    		Image back = arrimage.get(0);
	    		Game.startGame(h);
	    		scene3.scene3(stage,back,h,arrimage,arrName);
	    	});
	    });
	    Button b1 = buttons.get(1);
	    b1.setOnAction(e->{
	    	start.setOnAction(event->{
	    		Hero h = Game.availableHeroes.get(1);
	    		Image back = arrimage.get(1);
	    		Game.startGame(h);
	    		scene3.scene3(stage,back,h,arrimage,arrName);
	    	});
	    });
	    Button b2 = buttons.get(2);
	    b2.setOnAction(e->{
	    	start.setOnAction(event->{
	    		Hero h = Game.availableHeroes.get(2);
	    		Image back = arrimage.get(2);
	    		Game.startGame(h);
	    		scene3.scene3(stage,back,h,arrimage,arrName);
	    	});
	    });
	    Button b3 = buttons.get(3);
	    b3.setOnAction(e->{
	    	start.setOnAction(event->{
	    		Hero h = Game.availableHeroes.get(3);
	    		Image back = arrimage.get(3);
	    		Game.startGame(h);
	    		scene3.scene3(stage,back,h,arrimage,arrName);
	    	});
	    });
	    Button b4 = buttons.get(4);
	    b4.setOnAction(e->{
	    	start.setOnAction(event->{
	    		Hero h = Game.availableHeroes.get(4);
	    		Image back = arrimage.get(4);
	    		Game.startGame(h);
	    		scene3.scene3(stage,back,h,arrimage,arrName);
	    	});
	    });
	    Button b5 = buttons.get(5);
	    b5.setOnAction(e->{
	    	start.setOnAction(event->{
	    		Hero h = Game.availableHeroes.get(5);
	    		Image back = arrimage.get(5);
	    		Game.startGame(h);
	    		scene3.scene3(stage,back,h,arrimage,arrName);
	    	});
	    });
	    Button b6 = buttons.get(6);
	    b6.setOnAction(e->{
	    	start.setOnAction(event->{
	    		Hero h = Game.availableHeroes.get(6);
	    		Image back = arrimage.get(6);
	    		Game.startGame(h);
	    		scene3.scene3(stage,back,h,arrimage,arrName);
	    	});
	    });
	    Button b7 = buttons.get(7);
	    b7.setOnAction(e->{
	    	start.setOnAction(event->{
	    		Hero h = Game.availableHeroes.get(7);
	    		Image back = arrimage.get(7);
	    		Game.startGame(h);
	    		scene3.scene3(stage,back,h,arrimage,arrName);
	    	});
	    });
	    Image backgroundImage = new Image("avHeros back.jpg");
		BackgroundImage background = new BackgroundImage(backgroundImage, null, null, null, new BackgroundSize(1.0, 1.0, true, true, false, false));
	    root.setBackground(new Background(background));
	    root.setCenter(hbox); // Add
	    Scene scene2 = new Scene(root);
	    stage.setScene(scene2);
    	stage.setResizable(false);
	    stage.setFullScreen(true);
	    stage.show();
	    
	}
}
