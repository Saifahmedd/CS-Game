package views;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.characters.Hero;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Path;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import java.io.IOException;
import java.lang.Package;
import java.nio.file.Paths;
import java.util.ArrayList;

import engine.Game;



public class Main extends Application {

	public void start(Stage stage) {
		Group group = new Group();
		Image image = new Image("The Last of Us BackGround3.jpg");
		ImageView imageView = new ImageView(image);
		Text text = new Text("Start Game");
		Button b = new Button(text.getText());
		b.setFont(Font.font("Chiller",60));
		b.setTextFill(Color.WHITE);
		b.setBackground(null);
		BorderPane bP = new BorderPane(b);
		b.setOnMouseEntered(e-> {
			ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.2),b);
            scaleTransition.setToX(1.2);
            scaleTransition.setToY(1.2);
            scaleTransition.setAutoReverse(true);
            scaleTransition.play();
		});
		b.setOnMouseExited(e-> {
			ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.2), b);
		    scaleTransition.setToX(1);
		    scaleTransition.setToY(1);
		    scaleTransition.play();
		});	
		
		b.setOnAction(e-> {
			scene2.scene2(stage);
			});
		
		bP.setCenter(b);
		bP.setTranslateX(170);
		bP.setTranslateY(420);
		group.getChildren().addAll(imageView,bP);
		Scene scene = new Scene(group,1280,720);
		stage.setTitle("The Last Of Us");
		Image icon = new Image("The Last Of Us - Icon.jpg");
		stage.getIcons().add(icon);
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}
	
	
	public static void main(String[] args) {
		launch(args);
	}
}